SKYLINE CONSTRUCTION & TRADING — Premium static website
Upload index.html to the ROOT of your GitHub repository.
No framework or build step is required.
Cloudflare Pages settings for this static site:
- Production branch: main (or the branch shown in your GitHub repository)
- Build command: leave blank, or use exit 0
- Build output directory: /
Keep index.html at the repository root.
Contact details included: +92 313 9826270 | skyline4400.pk@gmail.com
Note: the monogram is a temporary text-based brand mark. Replace it with the official SKYLINE logo when available.
